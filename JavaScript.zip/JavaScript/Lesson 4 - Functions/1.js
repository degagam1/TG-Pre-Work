const takeOrder = () => {
  console.log('Order:pizza’); 
}; 

takeOrder(); 