const takeOrder = (topping) => {
  console.log(`Order: pizza topped with ${topping}`);
};

takeOrder('sundried tomatoes');