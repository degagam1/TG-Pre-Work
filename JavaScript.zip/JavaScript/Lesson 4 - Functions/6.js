//function declaration
function isGreaterThan (numberOne, numberTwo) {
  if(numberOne > numberTwo) {
     return true; 
     }
  else {
    return false; 
  }
}

console.log(isGreaterThan(4,5));