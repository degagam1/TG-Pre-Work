const takeOrder = (topping, crustType) => {
  console.log('Order: ' + crustType + ' crust pizza topped with ' + topping);
};

takeOrder('mushrooms', 'thin');
takeOrder('pineapple', 'stuffed'); 
takeOrder('bacon', 'deep dish'); 