console.log("favorite pizza topping: sundried tomatoes");
console.log("favorite book: Metamorphosis”);