// Log Codecademy in all uppercase letters
console.log('Codecademy'); 
console.log('Codecademy'.toUpperCase()); 

// Use a string method to log the following statment without whitespace at the beginning and end of it.
console.log('    Remove whitespace   '); 
console.log('    Remove whitespace   '.trim()); 


