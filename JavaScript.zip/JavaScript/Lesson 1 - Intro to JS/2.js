console.log('JavaScript'); 
console.log(33.7); 
console.log(true);
console.log(null);