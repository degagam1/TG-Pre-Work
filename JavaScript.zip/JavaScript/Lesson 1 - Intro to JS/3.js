console.log(3.5+26); 
console.log(2018-1969); 
console.log(65 / 240); 
console.log(0.2708 * 100); 