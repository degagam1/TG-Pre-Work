console.log(Math.random()*100); 
console.log(Math.floor(Math.random()*100));
console.log(Math.ceil(43.8));            
console.log(Number.isInteger(2017));


