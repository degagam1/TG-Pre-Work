const satellite = 'The Moon'; 
const galaxy = 'The Milky Way'; 

let stars = 'North Star'; 

const myNightSky = () => 'Night Sky: ' + satellite + ', ' + stars + ', ' + galaxy;  

console.log(myNightSky()); 