const visibleLightWaves = () => {
  let lightWaves = 'Moonlight'; 
  let region = 'The Arctic'; 
  console.log(lightWaves);
  if (region === 'The Arctic') {
    let lightWaves = 'Northern Lights'; 
      console.log(lightWaves);
  }
}; 

visibleLightWaves(); 

