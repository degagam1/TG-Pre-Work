const visibleLightWaves = () => {
  let lightWaves = 'Moonlight'; 
  console.log(lightWaves);
}; 

visibleLightWaves(); 
console.log(lightWaves);