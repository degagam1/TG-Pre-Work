const starCount = () => {
  let i = 5; 
  console.log(i); 
  for(let i = 0; i<12; i++) {
   console.log(i);  
  }
};

starCount(); 
console.log(i); 