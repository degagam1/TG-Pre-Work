let person = {
  name: 'Merry Degaga',
  age: 27, 
};

//dot notation 
//console.log(person.name);
//console.log(person.age);

//bracket notation 
console.log(person['name']); 
console.log(person['age']); 

