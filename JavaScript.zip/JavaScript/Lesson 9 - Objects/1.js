let person = {
  name: 'Merry Degaga',
  age: 27, 
};