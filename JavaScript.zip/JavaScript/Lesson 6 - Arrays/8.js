let condiments = ['Ketchup', 'Mustard', 'Soy Sauce', 'Sriracha'];

const utensils = ['Fork', 'Knife', 'Chopsticks', 'Spork'];

condiments.push('Hot sauce');
condiments = ['BBQ sauce']; 
console.log(condiments); 

utensils.pop();
console.log(utensils);
utensils = ['Fork']; 