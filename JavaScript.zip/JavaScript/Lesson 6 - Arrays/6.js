let newYearsResolutions = ['Run a marathon', 'Learn a new language', 'Read 52 books'];

newYearsResolutions.push('Eat less pizza'); 

newYearsResolutions.push('Fly in a hot air ballon');

console.log(newYearsResolutions); 

newYearsResolutions.pop(); 

console.log(newYearsResolutions); 