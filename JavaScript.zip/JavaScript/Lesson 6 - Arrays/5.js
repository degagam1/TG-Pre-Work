let newYearsResolutions = ['Run a marathon', 'Learn a new language', 'Read 52 books'];

console.log(newYearsResolutions.length);