let newYearsResolutions = ['Go skydiving', 'Drive across the country', 'Volunteer more']; 

console.log(newYearsResolutions); 