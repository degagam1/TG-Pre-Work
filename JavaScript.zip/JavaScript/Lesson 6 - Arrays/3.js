let newYearsResolutions = ['Go skydiving', 'Drive across the country', 'Volunteer more']; 

console.log(newYearsResolutions); 

let listItem = newYearsResolutions[0]; 
console.log(listItem); 

console.log(newYearsResolutions[2]);

console.log(newYearsResolutions[3]); 



