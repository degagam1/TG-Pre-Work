let isSoccerFan = false; 

if(isSoccerFan === true) {
  console.log('Goal!');
} 

else {
  console.log('No goal!');
}