let moonPhase = 'full';

if(moonPhase === 'full') {
  console.log('Howl!');
}

else {
  console.log('I swear I am not a werewolf.');
}


