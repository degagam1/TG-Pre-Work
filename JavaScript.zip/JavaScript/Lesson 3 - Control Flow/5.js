let hungerLevel = 10; 

if (hungerLevel > 7) {
  console.log('Time to eat!');
}

else {
  console.log('We can eat later!'); 
}