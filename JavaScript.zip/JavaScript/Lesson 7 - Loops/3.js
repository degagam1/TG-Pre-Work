let vacationSpots = ['Venice', 'Ethiopia', 'Greenland']; 

for(let vacationSpotIndex = 0; vacationSpotIndex<vacationSpots.length ;vacationSpotIndex++) {
  console.log(`I would love to visit ${vacationSpots[vacationSpotIndex]}`);
}