let vacationSpots = ['Venice', 'Ethiopia', 'Greenland']; 

for(let vacationSpotIndex = vacationSpots.length-1; vacationSpotIndex>= 0 ;vacationSpotIndex--) {
  console.log(`I would love to visit ${vacationSpots[vacationSpotIndex]}`);
}