let vacationSpots = ['Venice', 'Ethiopia', 'Greenland']; 

console.log(vacationSpots[0]);
console.log(vacationSpots[1]);
console.log(vacationSpots[2]); 