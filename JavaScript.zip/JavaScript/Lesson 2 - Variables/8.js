let myName = 'Merry Degaga'; 
let myCity = 'Boulder'; 
console.log(`My name is ${myName}. My favorite city is ${myCity}.`);