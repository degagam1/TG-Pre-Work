const entree = 'Enchiladas'; 
const price = 12; 
console.log(entree);
console.log(price);
entree = 'Tacos'; 