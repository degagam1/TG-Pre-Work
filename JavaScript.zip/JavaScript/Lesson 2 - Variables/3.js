let changeMe = true; 
changeMe = false; 
console.log(changeMe);