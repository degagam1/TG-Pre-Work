let favoriteAnimal = 'owl'; 
console.log('My favorite animal: ' + favoriteAnimal);