let molecule = 16;
let particle = 18;
let assay = 3;

// Add and assign to molecule below
molecule += 16; 

// Multiply and assign to particle below
particle *= 6.02; 

// Increment assay by 1
assay++;