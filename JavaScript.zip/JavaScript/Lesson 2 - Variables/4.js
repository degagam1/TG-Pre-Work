let notDefined; 
console.log(notDefined);

let valueless; 
console.log(valueless);