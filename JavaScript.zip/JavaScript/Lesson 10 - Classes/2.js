class Surgeon {
  constructor(name, department) {
    this.name = name; 
    this.department = department; 
  }
}