var pasta = "Spaghetti"; // ES5 syntax

var meat = "Pancetta"; // ES5 syntax

var sauce = "Eggs and cheese"; // ES5 syntax

// ES5
var carbonara = "You can make carbonara with " + pasta + ", " + meat + ", " + " and a sauce made with " + sauce + ".";