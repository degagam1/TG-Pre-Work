var pasta = "Spaghetti"; 
const meat = "Pancetta"; 
let sauce = "Eggs and cheese"; 

const carbonara = `You can make carbonara with ${pasta}, ${meat}, and a sauce made with ${sauce}.`; 