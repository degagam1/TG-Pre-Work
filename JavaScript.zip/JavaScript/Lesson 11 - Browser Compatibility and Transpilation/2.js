// Set the variable below to a number
let esFivePercentageSupport;
esFivePercentageSupport = 95.47; 

// Set the variable below to a number
let esSixTemplateLiterals = 86.59; 