const Airplane = require('./1.js');

function displayAirplane() {
  console.log(Airplane.myAirplane);
}; 

displayAirplane();