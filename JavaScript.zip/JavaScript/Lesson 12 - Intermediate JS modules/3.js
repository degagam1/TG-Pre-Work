const Airplane = require('./2-airplane.js'); 

console.log(Airplane.displayAirplane());