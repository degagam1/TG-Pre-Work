const Airplane = require('./4.js'); 

console.log(Airplane.displayAirplane());