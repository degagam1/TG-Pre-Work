let Airplane = {
  myAirplane: "StarJet",
};

module.exports = Airplane; 